@props(['route' => ''])

<a href="{{ $route }}" class="btn btn-sm btn-outline--primary">
    <i class="la la-undo"></i> @lang('Back')
</a>
