As it contains massive changes you need to update the full file. 
If you want to keep old data just import the update.sql to your database.

Changes We made :
[ADD] In admin panel advertisement limit removal added
[ADD] Max limit check added on trade request
[ADD] Kyc system added
[ADD] In advertimsent fixed rate (Advertiser can set his own rate instead of system rate) also added with margin.
[ADD] Maintenance mood added
[ADD] User public profile added
[ADD] User trade review system added
[ADD] To identify own advertisement, different background color added
[ADD] User location based search added
[ADD] Referral system added
[ADD] Search and filtering system for user
[ADD] Average trade speed of user added
[ADD] Showing advertisement unpublish reason added
[ADD] Admin can receive commission on completing a trade
[ADD] Logo uploading system for fiat gateways

[FIX] Some grammatical issues
[FIX] Some responsive issues
[FIX] Trade chat file download issue
[FIX] Email notification short codes issue
[FIX] User advertisement rate negative issue
[FIX] In user panel transaction table charge showing
